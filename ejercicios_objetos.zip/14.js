(function () {
  let inventario = { arepas: 20, empanadas: 8, jugos: 0, tintos: 40, pandebonos: 5 };

  function contarUnidades(inventario) {
    return Object.values(inventario).reduce((total, cantidad) => total + cantidad, 0);
  }

  // Retorna pares [clave, valor]. En cada vuelta par[0] es el producto y par[1] su cantidad.
  function obtenerStockBajo(inventario) {
    return Object.entries(inventario).filter((par) => par[1] > 0 && par[1] < 10);
  }

  function obtenerAgotados(inventario) {
    return Object.entries(inventario)
      .filter((par) => par[1] === 0)
      .map((par) => par[0]);
  }

  function unirConComas(lista) {
    return lista.reduce((texto, elemento, i) => (i === 0 ? "" + elemento : texto + ", " + elemento), "");
  }

  function formatearPares(pares) {
    return unirConComas(pares.map((par) => par[0] + " (" + par[1] + ")"));
  }

  let stockBajo = obtenerStockBajo(inventario);
  let agotados = obtenerAgotados(inventario);
  console.log("Productos: " + Object.keys(inventario).length);
  console.log("Unidades en total: " + contarUnidades(inventario));
  console.log("Stock bajo: " + (stockBajo.length > 0 ? formatearPares(stockBajo) : "ninguno"));
  console.log("Agotados: " + (agotados.length > 0 ? unirConComas(agotados) : "ninguno"));
})();
