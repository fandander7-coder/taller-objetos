(function () {
  function crearReserva(cliente, adultos) {
    return {
      cliente: cliente,
      actividad: "Rafting río Fonce",
      adultos: adultos,
      seguro: true
    };
  }

  function calcularTotal(reserva) {
    let personas = reserva.adultos;
    let total = reserva.adultos * 70000;
    if ("menores" in reserva) {
      total += reserva.menores * 50000;
      personas += reserva.menores;
    }
    if ("seguro" in reserva) {
      total += personas * 8000;
    }
    return total;
  }

  function mostrarReserva(reserva) {
    console.log("--- Reserva ---");
    console.log("Cliente: " + reserva.cliente);
    console.log("Actividad: " + reserva.actividad);
    console.log("Adultos: " + reserva.adultos);
    if ("menores" in reserva) {
      console.log("Menores: " + reserva.menores);
    }
    console.log("Seguro: " + ("seguro" in reserva ? "incluido" : "no incluido"));
    console.log("Total: $" + calcularTotal(reserva));
  }

  // Después de delete reserva.seguro, reserva.seguro vale undefined y la clave
  // ya no existe ("seguro" in reserva da false). Con reserva.seguro = false la
  // clave seguiría existiendo con valor false.
  // Si no van menores, reserva.menores vale undefined; por eso en calcularTotal
  // se pregunta primero si la clave existe (undefined * 50000 daría NaN).
  let cliente = prompt("Cliente:");
  let adultos = Number(prompt("Adultos:"));
  let reserva = crearReserva(cliente, adultos);

  let hayMenores = prompt("¿Van menores de edad? (si/no):");
  if (hayMenores !== null && hayMenores.trim().toLowerCase() === "si") {
    reserva.menores = Number(prompt("¿Cuántos menores?:"));
  }

  let rechazaSeguro = prompt("¿Rechaza el seguro? (si/no):");
  if (rechazaSeguro !== null && rechazaSeguro.trim().toLowerCase() === "si") {
    delete reserva.seguro;
  }

  mostrarReserva(reserva);
})();
