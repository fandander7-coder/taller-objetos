(function () {
  let cliente = {
    nombre: "Laura Gómez",
    telefonos: ["3104567890", "6077241234"],
    direccion: { calle: "Calle 12 # 9-45", barrio: "Centro", ciudad: "San Gil" }
  };
  let clienteNuevo = { nombre: "Pedro Ruiz", telefonos: [] };

  function unirConComas(lista) {
    let texto = "";
    for (let i = 0; i < lista.length; i++) {
      if (i > 0) {
        texto += ", ";
      }
      texto += lista[i];
    }
    return texto;
  }

  function mostrarFicha(cliente) {
    console.log(cliente.nombre);
    console.log("Teléfonos: " + (cliente.telefonos.length > 0 ? unirConComas(cliente.telefonos) : "ninguno"));
    if (cliente.direccion !== undefined) {
      console.log("Dirección: " + cliente.direccion.calle + ", " + cliente.direccion.barrio + ", " + cliente.direccion.ciudad);
    } else {
      console.log("Dirección: sin dirección");
    }
  }

  function cambiarDireccion(cliente, calle, barrio) {
    cliente.direccion.calle = calle;
    cliente.direccion.barrio = barrio;
  }

  function obtenerCiudad(cliente) {
    if (cliente.direccion !== undefined && cliente.direccion.ciudad !== undefined) {
      return cliente.direccion.ciudad;
    }
    return "sin dirección";
  }

  // console.log(clienteNuevo.direccion.ciudad) detiene el programa con un
  // TypeError: clienteNuevo.direccion es undefined y undefined no tiene
  // propiedades. Leer una clave que no existe da undefined sin error, pero
  // bajar un nivel más sobre ese undefined sí rompe. Antes de bajar un nivel
  // hay que revisar que el nivel actual exista.
  console.log("--- Antes ---");
  mostrarFicha(cliente);

  let telefono = prompt("Nuevo teléfono:");
  let barrio = prompt("Nuevo barrio:");
  let calle = prompt("Nueva calle:");
  cliente.telefonos.push(telefono);
  cambiarDireccion(cliente, calle, barrio);

  console.log("--- Después ---");
  mostrarFicha(cliente);
  console.log("Ciudad de " + clienteNuevo.nombre + ": " + obtenerCiudad(clienteNuevo));
})();
