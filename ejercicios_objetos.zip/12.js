(function () {
  // a === b da false porque === entre objetos compara referencias, no
  // contenido: a y b son dos objetos distintos en memoria aunque tengan
  // los mismos datos.
  let a = { nombre: "Morral", precio: 85000 };
  let b = { nombre: "Morral", precio: 85000 };
  console.log(a === b);

  function contarClaves(objeto) {
    let cantidad = 0;
    for (let clave in objeto) {
      cantidad++;
    }
    return cantidad;
  }

  // Si solo se recorren las claves de a, el caso 3 (a con menos claves que b)
  // daría true por error. Comparar primero la cantidad de claves lo arregla.
  // El orden de las claves no debe importar: se busca cada clave por nombre.
  function sonIguales(a, b) {
    if (contarClaves(a) !== contarClaves(b)) {
      return false;
    }
    for (let clave in a) {
      if (!Object.prototype.hasOwnProperty.call(b, clave)) {
        return false;
      }
      if (a[clave] !== b[clave]) {
        return false;
      }
    }
    return true;
  }

  let caso1a = { nombre: "Morral", precio: 85000 };
  let caso1b = { nombre: "Morral", precio: 85000 };
  let caso2a = { nombre: "Morral", precio: 85000 };
  let caso2b = { nombre: "Morral", precio: 90000 };
  let caso3a = { nombre: "Morral" };
  let caso3b = { nombre: "Morral", precio: 85000 };
  let caso4a = { nombre: "Morral", precio: 85000 };
  let caso4b = { precio: 85000, nombre: "Morral" };

  console.log("Caso 1, iguales: " + sonIguales(caso1a, caso1b));
  console.log("Caso 2, distinto precio: " + sonIguales(caso2a, caso2b));
  console.log("Caso 3, a tiene menos claves que b: " + sonIguales(caso3a, caso3b));
  console.log("Caso 4, mismas claves en otro orden: " + sonIguales(caso4a, caso4b));
})();
