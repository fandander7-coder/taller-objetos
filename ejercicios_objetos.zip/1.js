(function () {
  function leerAprendiz() {
    let aprendiz = {};
    aprendiz.nombre = prompt("Nombre:");
    aprendiz.edad = Number(prompt("Edad:"));
    aprendiz.ficha = prompt("Número de ficha:");
    aprendiz.programa = prompt("Programa:");
    aprendiz.mayorDeEdad = aprendiz.edad >= 18;
    return aprendiz;
  }

  function mostrarFicha(aprendiz) {
    console.log("--- Ficha del aprendiz ---");
    console.log("Nombre: " + aprendiz.nombre);
    console.log("Edad: " + aprendiz.edad + " años");
    console.log("Ficha: " + aprendiz.ficha);
    console.log("Programa: " + aprendiz.programa);
    console.log("Mayor de edad: " + (aprendiz.mayorDeEdad ? "sí" : "no"));
  }

  // typeof aprendiz.edad -> "number", porque se convirtió con Number().
  // mayorDeEdad se guarda como true/false porque es un dato lógico que se
  // puede usar en condiciones; "sí"/"no" es solo una forma de presentarlo.
  let aprendiz = leerAprendiz();
  mostrarFicha(aprendiz);
})();
