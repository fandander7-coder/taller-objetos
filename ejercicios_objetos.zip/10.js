(function () {
  // ----- Parte A -----
  // Predicción (escrita antes de ejecutar): imprime 45000 Ana La Playa.
  // - copia1 = pedido no crea otro objeto: es otro nombre para el mismo, así
  //   que copia1.total = 45000 cambia también pedido.total.
  // - copia2 sí es un objeto nuevo, por eso copia2.cliente = "Luis" no toca a
  //   pedido (sigue "Ana").
  // - Pero copia2.entrega apunta al MISMO objeto entrega que pedido.entrega,
  //   así que cambiar el barrio por copia2 también lo cambia en el original.
  // Resumen: la copia es superficial; los objetos anidados se comparten.
  let pedido = { cliente: "Ana", total: 30000, entrega: { barrio: "Centro", hora: "7:00 pm" } };
  let copia1 = pedido;
  copia1.total = 45000;
  let copia2 = { cliente: pedido.cliente, total: pedido.total, entrega: pedido.entrega };
  copia2.cliente = "Luis";
  copia2.entrega.barrio = "La Playa";
  console.log(pedido.total, pedido.cliente, pedido.entrega.barrio);

  // ----- Parte B -----
  function clonarEntrega(entrega) {
    return { barrio: entrega.barrio, hora: entrega.hora };
  }

  function clonarPedido(pedido) {
    return {
      cliente: pedido.cliente,
      total: pedido.total,
      entrega: clonarEntrega(pedido.entrega)
    };
  }

  let original = { cliente: "Ana", total: 30000, entrega: { barrio: "Centro", hora: "7:00 pm" } };
  let copia = clonarPedido(original);
  copia.entrega.barrio = "La Playa";
  console.log("Barrio del original: " + original.entrega.barrio);
  console.log("Barrio de la copia: " + copia.entrega.barrio);
})();
