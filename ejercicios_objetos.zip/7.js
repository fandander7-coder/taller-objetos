(function () {
  function contarPalabras(frase) {
    let palabras = frase.toLowerCase().split(" ");
    let contador = {};
    for (let i = 0; i < palabras.length; i++) {
      let palabra = palabras[i];
      if (palabra === "") {
        continue;
      }
      if (Object.prototype.hasOwnProperty.call(contador, palabra)) {
        contador[palabra] = contador[palabra] + 1;
      } else {
        contador[palabra] = 1;
      }
    }
    return contador;
  }

  function contarClaves(objeto) {
    let cantidad = 0;
    for (let clave in objeto) {
      cantidad++;
    }
    return cantidad;
  }

  function buscarClaveMayor(objeto) {
    let mejor;
    for (let clave in objeto) {
      if (mejor === undefined || objeto[clave] > objeto[mejor]) {
        mejor = clave;
      }
    }
    return mejor;
  }

  // Un array de contadores no sirve porque las palabras no son posiciones
  // 0, 1, 2...: son textos que no se conocen de antemano.
  // Cuando una palabra llega por primera vez, contador[palabra] vale undefined;
  // sumarle 1 daría NaN y crearía una clave con basura (igual que "Efectivo"
  // en la caja registradora). Por eso se pregunta si existe antes de sumar.
  let frase = prompt("Frase:");
  if (frase === null || frase.trim() === "") {
    console.log("No se escribió ninguna frase");
  } else {
    let contador = contarPalabras(frase);
    for (let palabra in contador) {
      console.log(palabra + ": " + contador[palabra]);
    }
    console.log("Palabras distintas: " + contarClaves(contador));
    let masRepetida = buscarClaveMayor(contador);
    console.log("Más repetida: " + masRepetida + " (" + contador[masRepetida] + " veces)");
  }
})();
