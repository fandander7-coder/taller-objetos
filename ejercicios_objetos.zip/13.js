(function () {
  let notas = { matematicas: 4.2, ingles: 3.1, programacion: 4.8, etica: 3.9 };

  // La función que desapareció es contarClaves: ahora basta con
  // Object.keys(objeto).length, porque keys retorna un array y los arrays sí tienen length.

  function calcularPromedioObjeto(objeto) {
    let valores = Object.values(objeto);
    let suma = valores.reduce((total, valor) => total + valor, 0);
    return suma / valores.length;
  }

  function buscarClaveMayor(objeto) {
    let claves = Object.keys(objeto);
    return claves.reduce((mejor, clave) => (objeto[clave] > objeto[mejor] ? clave : mejor), claves[0]);
  }

  // Dentro del callback se llega al valor con objeto[clave].
  function filtrarClavesMenores(objeto, limite) {
    return Object.keys(objeto).filter((clave) => objeto[clave] < limite);
  }

  function unirConComas(lista) {
    return lista.reduce((texto, elemento, i) => (i === 0 ? "" + elemento : texto + ", " + elemento), "");
  }

  Object.keys(notas).forEach((materia) => {
    console.log(materia + ": " + notas[materia]);
  });
  console.log("Promedio: " + calcularPromedioObjeto(notas).toFixed(1));
  console.log("Mejor materia: " + buscarClaveMayor(notas));
  let reforzar = filtrarClavesMenores(notas, 3.5);
  console.log("Por reforzar: " + (reforzar.length > 0 ? unirConComas(reforzar) : "ninguna"));
})();
