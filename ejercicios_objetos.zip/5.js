(function () {
  let notas = { matematicas: 4.2, ingles: 3.1, programacion: 4.8, etica: 3.9 };

  function contarClaves(objeto) {
    let cantidad = 0;
    for (let clave in objeto) {
      cantidad++;
    }
    return cantidad;
  }

  function calcularPromedioObjeto(objeto) {
    let suma = 0;
    for (let clave in objeto) {
      suma += objeto[clave];
    }
    return suma / contarClaves(objeto);
  }

  function buscarClaveMayor(objeto) {
    let mejor;
    for (let clave in objeto) {
      if (mejor === undefined || objeto[clave] > objeto[mejor]) {
        mejor = clave;
      }
    }
    return mejor;
  }

  function filtrarClavesMenores(objeto, limite) {
    let resultado = [];
    for (let clave in objeto) {
      if (objeto[clave] < limite) {
        resultado.push(clave);
      }
    }
    return resultado;
  }

  function unirConComas(lista) {
    let texto = "";
    for (let i = 0; i < lista.length; i++) {
      if (i > 0) {
        texto += ", ";
      }
      texto += lista[i];
    }
    return texto;
  }

  // notas.length vale undefined: los objetos no tienen length.
  // Las claves se cuentan con un for...in sumando 1 por vuelta (contarClaves).
  for (let materia in notas) {
    console.log(materia + ": " + notas[materia]);
  }
  console.log("Promedio: " + calcularPromedioObjeto(notas).toFixed(1));
  console.log("Mejor materia: " + buscarClaveMayor(notas));
  let reforzar = filtrarClavesMenores(notas, 3.5);
  console.log("Por reforzar: " + (reforzar.length > 0 ? unirConComas(reforzar) : "ninguna"));
})();
