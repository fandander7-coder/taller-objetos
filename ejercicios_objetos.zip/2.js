(function () {
  let cliente = { nombre: "Jorge Díaz", telefono: "3001234567", barrio: "La Playa", ciudad: "San Gil" };

  function existeClave(objeto, clave) {
    return Object.prototype.hasOwnProperty.call(objeto, clave);
  }

  function actualizarDato(objeto, clave, valor) {
    objeto[clave] = valor;
  }

  function mostrarCliente(cliente) {
    console.log("Perfil final:");
    console.log("Nombre: " + cliente.nombre);
    console.log("Teléfono: " + cliente.telefono);
    console.log("Barrio: " + cliente.barrio);
    console.log("Ciudad: " + cliente.ciudad);
  }

  // cliente.clave busca una propiedad llamada literalmente "clave".
  // cliente[clave] usa el texto guardado en la variable clave (ej. "barrio").
  // Aquí solo sirve la segunda porque el nombre lo escribe el usuario.
  let clave = prompt("¿Qué dato quieres cambiar?");
  while (clave !== null && clave.trim().toLowerCase() !== "fin") {
    clave = clave.trim().toLowerCase();
    if (existeClave(cliente, clave)) {
      let valor = prompt("Nuevo valor:");
      actualizarDato(cliente, clave, valor);
      console.log("Actualizado: " + clave + " = " + valor);
    } else {
      console.log("El dato " + clave + " no existe");
    }
    clave = prompt("¿Qué dato quieres cambiar?");
  }

  mostrarCliente(cliente);
})();
