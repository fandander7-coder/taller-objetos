(function () {
  let inventario = { arepas: 20, empanadas: 35, jugos: 15, tintos: 40 };

  function existeClave(objeto, clave) {
    return Object.prototype.hasOwnProperty.call(objeto, clave);
  }

  function vender(inventario, producto, cantidad) {
    if (!existeClave(inventario, producto)) {
      return "No vendemos " + producto;
    }
    if (isNaN(cantidad) || cantidad <= 0) {
      return "Cantidad no válida";
    }
    if (inventario[producto] < cantidad) {
      return "Solo quedan " + inventario[producto] + " " + producto;
    }
    inventario[producto] = inventario[producto] - cantidad;
    return "Vendidas " + cantidad + " " + producto + ". Quedan " + inventario[producto];
  }

  function obtenerAgotados(inventario) {
    let agotados = [];
    for (let producto in inventario) {
      if (inventario[producto] === 0) {
        agotados.push(producto);
      }
    }
    return agotados;
  }

  function unirConComas(lista) {
    let texto = "";
    for (let i = 0; i < lista.length; i++) {
      if (i > 0) {
        texto += ", ";
      }
      texto += lista[i];
    }
    return texto;
  }

  // Si se valida primero el stock, inventario["pandebono"] vale undefined y
  // undefined < 30 es false: pasaría la validación de stock y se crearía la
  // clave "pandebono" con NaN. Por eso se valida primero que exista.
  let producto = prompt("Producto:");
  while (producto !== null && producto.trim().toLowerCase() !== "fin") {
    producto = producto.trim().toLowerCase();
    let cantidad = 0;
    if (existeClave(inventario, producto)) {
      cantidad = Number(prompt("Cantidad:"));
    }
    console.log(vender(inventario, producto, cantidad));
    producto = prompt("Producto:");
  }

  console.log("Inventario final:");
  for (let item in inventario) {
    console.log(item + ": " + inventario[item]);
  }
  let agotados = obtenerAgotados(inventario);
  console.log("Agotados: " + (agotados.length > 0 ? unirConComas(agotados) : "ninguno"));
})();
