(function () {
  let codigos = { bogota: "BOG", medellin: "MDE", bucaramanga: "BGA", cali: "CLO" };
  let zonas = { centro: "A", laPlaya: "B", pabloVI: "A" };

  function unirConComas(lista) {
    return lista.reduce((texto, elemento, i) => (i === 0 ? "" + elemento : texto + ", " + elemento), "");
  }

  function invertir(objeto) {
    let invertido = {};
    Object.entries(objeto).forEach((par) => {
      invertido[par[1]] = par[0];
    });
    return invertido;
  }

  // Con zonas, invertir pierde "centro": la zona "A" se escribe primero con
  // centro y luego pabloVI sobrescribe ese valor, porque las claves no se repiten.
  // En invertirAgrupando, si la zona ya existe se agrega el barrio al array
  // con push; si llega por primera vez se crea el array con ese barrio.
  // Es el mismo patrón del contador del ejercicio 7.
  function invertirAgrupando(objeto) {
    let agrupado = {};
    Object.entries(objeto).forEach((par) => {
      let barrio = par[0];
      let zona = par[1];
      if (Object.prototype.hasOwnProperty.call(agrupado, zona)) {
        agrupado[zona].push(barrio);
      } else {
        agrupado[zona] = [barrio];
      }
    });
    return agrupado;
  }

  // Parte A
  let ciudades = invertir(codigos);
  let codigo = prompt("Código:");
  while (codigo !== null && codigo.trim().toLowerCase() !== "fin") {
    codigo = codigo.trim().toUpperCase();
    if (Object.prototype.hasOwnProperty.call(ciudades, codigo)) {
      console.log(codigo + ": " + ciudades[codigo]);
    } else {
      console.log("No hay ciudad con el código " + codigo);
    }
    codigo = prompt("Código:");
  }

  // Parte B
  let agrupadas = invertirAgrupando(zonas);
  console.log("Zonas agrupadas:");
  Object.entries(agrupadas).forEach((par) => {
    console.log(par[0] + ": " + unirConComas(par[1]));
  });
})();
