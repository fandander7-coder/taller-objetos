(function () {
  let producto = { nombre: "Morral", precio: 85000, stock: 12 };

  function aplicarDescuento(producto, porcentaje) {
    let oferta = {};
    for (let clave in producto) {
      oferta[clave] = producto[clave];
    }
    oferta.precio = Math.round(producto.precio * (1 - porcentaje / 100));
    oferta.precioAnterior = producto.precio;
    return oferta;
  }

  function mostrarProducto(producto) {
    let texto = producto.nombre + " - $" + producto.precio;
    if ("precioAnterior" in producto) {
      texto += " (antes $" + producto.precioAnterior + ")";
    }
    texto += " - " + producto.stock + " unidades";
    console.log(texto);
  }

  // Prueba mala: si dentro de la función se escribe
  //   let oferta = producto; oferta.precio = ...
  // el original también cambia, porque oferta y producto son dos nombres
  // para el MISMO objeto (se pasan por referencia). Por eso se copia clave por clave.
  let porcentaje = Number(prompt("Porcentaje de descuento:"));
  let oferta = aplicarDescuento(producto, porcentaje);
  console.log("Original: " + producto.nombre + " - $" + producto.precio + " - " + producto.stock + " unidades");
  mostrarProducto(oferta);
})();
