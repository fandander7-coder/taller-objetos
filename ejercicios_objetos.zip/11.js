(function () {
  let precios = { arepa: 3500, empanada: 2500, jugo: 4000, tinto: 1500 };
  let items = {};

  function existeClave(objeto, clave) {
    return Object.prototype.hasOwnProperty.call(objeto, clave);
  }

  function agregarItem(items, producto, cantidad) {
    if (existeClave(items, producto)) {
      items[producto] = items[producto] + cantidad;
    } else {
      items[producto] = cantidad;
    }
  }

  function calcularSubtotal(items, precios) {
    let subtotal = 0;
    for (let producto in items) {
      subtotal += items[producto] * precios[producto];
    }
    return subtotal;
  }

  function calcularDomicilio(subtotal) {
    return subtotal < 20000 ? 3000 : 0;
  }

  function mostrarDetalle(items, precios) {
    console.log("Detalle:");
    for (let producto in items) {
      console.log(producto + " x" + items[producto] + " = $" + items[producto] * precios[producto]);
    }
  }

  // items y precios comparten claves, igual que los arrays paralelos, pero
  // sin depender de que las posiciones coincidan: se llega al precio por el nombre.
  // La primera vez que llega "empanada", items["empanada"] vale undefined;
  // por eso se crea con la cantidad en lugar de sumarla.
  let producto = prompt("Producto:");
  while (producto !== null && producto.trim().toLowerCase() !== "fin") {
    producto = producto.trim().toLowerCase();
    if (existeClave(precios, producto)) {
      let cantidad = Number(prompt("Cantidad:"));
      if (isNaN(cantidad) || cantidad <= 0) {
        console.log("Cantidad no válida");
      } else {
        agregarItem(items, producto, cantidad);
      }
    } else {
      console.log(producto + " no está en el menú");
    }
    producto = prompt("Producto:");
  }

  let subtotal = calcularSubtotal(items, precios);
  if (subtotal === 0) {
    console.log("No se pidió ningún producto");
  } else {
    let domicilio = calcularDomicilio(subtotal);
    mostrarDetalle(items, precios);
    console.log("Subtotal: $" + subtotal);
    console.log("Domicilio: $" + domicilio);
    console.log("Total: $" + (subtotal + domicilio));
  }
})();
