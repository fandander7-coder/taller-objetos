(function () {
  let glosario = {
    api: "Conjunto de reglas para que dos programas se comuniquen.",
    servidor: "Programa que recibe peticiones y devuelve respuestas.",
    ruta: "Dirección a la que llega una petición, como /productos.",
    middleware: "Función que se ejecuta entre la petición y la respuesta.",
    endpoint: "Combinación de un método HTTP y una ruta."
  };

  function buscarDefinicion(glosario, termino) {
    if (Object.prototype.hasOwnProperty.call(glosario, termino)) {
      return glosario[termino];
    }
    return undefined;
  }

  function contarClaves(objeto) {
    let cantidad = 0;
    for (let clave in objeto) {
      cantidad++;
    }
    return cantidad;
  }

  // buscarDefinicion no necesita ciclo porque un objeto llega directo a la
  // clave por su nombre (glosario[termino]); en un array había que revisar
  // posición por posición hasta encontrar el elemento.
  let termino = prompt("Término:");
  while (termino !== null && termino.trim().toLowerCase() !== "fin") {
    termino = termino.trim().toLowerCase();
    let definicion = buscarDefinicion(glosario, termino);
    if (definicion !== undefined) {
      console.log(termino + ": " + definicion);
    } else {
      console.log('"' + termino + '" no está en el glosario');
      let agregar = prompt("¿Quieres agregarlo? (si/no):");
      if (agregar !== null && agregar.trim().toLowerCase() === "si") {
        glosario[termino] = prompt("Definición:");
        console.log("Agregado");
      }
    }
    termino = prompt("Término:");
  }

  console.log("El glosario tiene " + contarClaves(glosario) + " términos");
})();
